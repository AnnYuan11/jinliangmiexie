class Config {
  constructor() {
  }
}
// Config.baseUrl = "https://www.jlzn365.com";
Config.baseUrl = "https://www.jlzn365.com";
export { Config };